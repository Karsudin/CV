"""
effects/nebula_effect.py

Effect "Nebula" -- partikel tersebar acak di ruang 3D. Effect DEFAULT/idle.
"""

import numpy as np
from effects.base_effect import BaseEffect


class NebulaEffect(BaseEffect):
    def get_positions(self, num_particles):
        return np.random.uniform(-4.0, 4.0, (num_particles, 3)).astype(np.float32)

    def get_color(self):
        return (1.0, 0.55, 0.1)  # oranye
