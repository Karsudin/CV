"""
effects/text_effect.py

Effect teks (misal nama) yang dibentuk dari partikel: render teks ke gambar
hitam-putih, ambil koordinat pixel putihnya, jadikan posisi partikel.
"""

import cv2
import numpy as np
from effects.base_effect import BaseEffect


class TextEffect(BaseEffect):
    def __init__(self, text="Karsudin"):
        self.text = text

    def get_positions(self, num_particles):
        # 1. Kanvas hitam sebagai "cetakan" (tinggi=200, lebar=600)
        canvas = np.zeros((200, 600), dtype=np.uint8)

        # 2. Gambar teks putih di atas kanvas
        cv2.putText(canvas, self.text, (50, 130), cv2.FONT_HERSHEY_SIMPLEX, 2.0, 255, 4)

        # 3. Koordinat semua pixel yang merupakan bagian teks
        y_indices, x_indices = np.where(canvas > 0)

        # 4. Pilih 'num_particles' pixel acak dari pixel teks
        chosen = np.random.choice(len(x_indices), num_particles)

        # 5. Skala pixel -> ruang 3D, (0,0) di tengah; Y dibalik (sumbu Y gambar terbalik)
        x = (x_indices[chosen] - 300) / 60.0
        y = -(y_indices[chosen] - 100) / 60.0

        # 6. Teks itu 2D -> sumbu Z hampir datar
        z = np.random.uniform(-0.1, 0.1, num_particles)

        return np.stack([x, y, z], axis=-1).astype(np.float32)

    def get_color(self):
        return (0.1, 1.0, 0.4)  # hijau terang

    def get_motion_type(self):
        return "idle"  # goyang halus, tetap terbaca
