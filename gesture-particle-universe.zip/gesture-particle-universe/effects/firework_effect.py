"""
effects/firework_effect.py

Effect "Fireworks" -- BEBERAPA letusan independen sekaligus, tiap letusan
punya titik pusat & warna sendiri. Partikel meluncur lalu jatuh karena
gravitasi, lalu lahir ulang (loop) per kelompok.
"""

import numpy as np
from effects.base_effect import BaseEffect


class FireworkEffect(BaseEffect):
    def __init__(self, num_groups=4):
        self.num_groups = num_groups
        self.positions = None
        self.velocities = None
        self.life = None                 # 1.0 = baru lahir, 0.0 = mati
        self.group_id = None             # tiap partikel milik grup ke berapa
        self.group_centers = None        # titik pusat letusan tiap grup
        self.group_colors = None         # warna tiap grup
        self.colors_per_particle = None  # warna final tiap partikel

    def get_positions(self, num_particles):
        self.positions = np.zeros((num_particles, 3), dtype=np.float32)
        self.velocities = np.zeros((num_particles, 3), dtype=np.float32)
        self.life = np.zeros(num_particles, dtype=np.float32)

        # Bagi rata partikel ke grup 0..num_groups-1
        self.group_id = np.arange(num_particles) % self.num_groups

        self.group_centers = np.random.uniform(
            -2.5, 2.5, (self.num_groups, 3)
        ).astype(np.float32)
        self.group_colors = np.random.uniform(
            0.4, 1.0, (self.num_groups, 3)
        ).astype(np.float32)
        self.colors_per_particle = np.zeros((num_particles, 3), dtype=np.float32)

        self._respawn_particles(np.ones(num_particles, dtype=bool))
        return self.positions

    def update(self, dt):
        if self.positions is None:
            return

        self.positions += self.velocities * dt
        self.velocities[:, 1] -= 2.0 * dt   # gravitasi
        self.life -= dt * 0.4               # seberapa cepat 1 siklus habis

        dead_mask = self.life <= 0
        if np.any(dead_mask):
            self._respawn_particles(dead_mask)

    def get_color(self):
        return (1.0, 1.0, 1.0)  # fallback; yang dipakai get_colors_array()

    def get_colors_array(self, num_particles):
        return self.colors_per_particle

    def get_motion_type(self):
        return "none"  # gerakan sudah diurus update()

    def _respawn_particles(self, mask):
        """Melahirkan ulang partikel 'mati' dari titik pusat grup masing-masing."""
        my_groups = self.group_id[mask]
        count = int(np.sum(mask))

        self.positions[mask] = self.group_centers[my_groups]

        direction = np.random.uniform(-1, 1, (count, 3))
        speed = np.random.uniform(1.5, 3.5, count)
        norm = np.linalg.norm(direction, axis=1, keepdims=True)
        norm[norm == 0] = 1
        self.velocities[mask] = (direction / norm * speed[:, np.newaxis]).astype(np.float32)
        self.life[mask] = 1.0

        # Warna baru acak tiap kali grup meletus ulang
        for g in np.unique(my_groups):
            self.group_colors[g] = np.random.uniform(0.4, 1.0, 3)
        self.colors_per_particle[mask] = self.group_colors[my_groups]
