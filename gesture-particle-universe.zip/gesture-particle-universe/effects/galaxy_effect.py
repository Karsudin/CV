"""
effects/galaxy_effect.py

Effect "Galaxy" -- partikel membentuk pola spiral multi-lengan.
"""

import numpy as np
from effects.base_effect import BaseEffect


class GalaxyEffect(BaseEffect):
    def __init__(self, num_arms=3, max_radius=4.0, twist=2.5, noise=0.25):
        self.num_arms = num_arms      # jumlah lengan spiral
        self.max_radius = max_radius  # jarak terjauh dari pusat
        self.twist = twist            # kerapatan lengkungan spiral
        self.noise = noise            # variasi acak agar tidak terlalu rapi

    def get_positions(self, num_particles):
        radius = np.random.uniform(0, self.max_radius, num_particles)

        # Tiap partikel milik satu lengan; lengan dimulai merata mengelilingi pusat
        arm_index = np.random.randint(0, self.num_arms, num_particles)
        arm_offset = arm_index * (2 * np.pi / self.num_arms)

        # Makin jauh dari pusat, makin berputar -> inilah spiralnya
        spiral_angle = radius * self.twist + arm_offset

        noise_offset = np.random.uniform(-self.noise, self.noise, num_particles)

        x = radius * np.cos(spiral_angle) + noise_offset
        z = radius * np.sin(spiral_angle) + noise_offset
        y = np.random.uniform(-0.3, 0.3, num_particles)

        return np.stack([x, y, z], axis=-1).astype(np.float32)

    def get_color(self):
        return (0.6, 0.4, 1.0)  # ungu

    def get_tilt(self):
        return 35.0

    def get_motion_type(self):
        return "full"
