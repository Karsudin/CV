"""
effects/lightning_effect.py

Effect "Lightning" -- partikel membentuk garis zigzag menyerupai petir,
dari atas ke bawah (beberapa sambaran sekaligus).
"""

import numpy as np
from effects.base_effect import BaseEffect


class LightningEffect(BaseEffect):
    def __init__(self, num_bolts=3, height=4.0, jaggedness=0.4):
        self.num_bolts = num_bolts      # jumlah sambaran
        self.height = height            # panjang petir atas-bawah
        self.jaggedness = jaggedness    # besar zigzag

    def get_positions(self, num_particles):
        particles_per_bolt = num_particles // self.num_bolts
        all_points = []

        for _ in range(self.num_bolts):
            start_x = np.random.uniform(-2.5, 2.5)
            start_z = np.random.uniform(-1.0, 1.0)
            all_points.append(
                self._generate_bolt_path(particles_per_bolt, start_x, start_z)
            )

        positions = np.concatenate(all_points, axis=0)

        # Sisa partikel (pembagian tidak bulat) ditaruh dekat pusat
        remainder = num_particles - positions.shape[0]
        if remainder > 0:
            extra = np.random.uniform(-0.05, 0.05, (remainder, 3))
            positions = np.concatenate([positions, extra], axis=0)

        return positions.astype(np.float32)

    def get_color(self):
        return (0.7, 0.85, 1.0)  # putih kebiruan

    def get_motion_type(self):
        return "none"  # petir terasa lebih tajam kalau diam

    def _generate_bolt_path(self, num_points, start_x, start_z):
        """Satu jalur petir dari atas ke bawah dengan zigzag acak."""
        y_values = np.linspace(self.height / 2, -self.height / 2, num_points)
        x_values = np.full(num_points, start_x, dtype=np.float64)
        z_values = np.full(num_points, start_z, dtype=np.float64)

        offset_x = np.random.uniform(-self.jaggedness, self.jaggedness, num_points)
        offset_z = np.random.uniform(-self.jaggedness, self.jaggedness, num_points)
        offset_x[0] = offset_x[-1] = 0  # ujung atas-bawah tidak digeser
        offset_z[0] = offset_z[-1] = 0

        return np.stack([x_values + offset_x, y_values, z_values + offset_z], axis=-1)
