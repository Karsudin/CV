"""
effects/saturn_effect.py

Effect "Saturnus" -- bola inti + cincin datar. Inti dan cincin beda warna.
"""

import numpy as np
from effects.base_effect import BaseEffect

CORE_RATIO = 0.4  # 40% partikel untuk inti, sisanya cincin


class SaturnEffect(BaseEffect):
    def __init__(self, core_radius=1.3, ring_inner=1.8, ring_outer=3.5):
        self.core_radius = core_radius
        self.ring_inner = ring_inner
        self.ring_outer = ring_outer

    def get_positions(self, num_particles):
        num_core = int(num_particles * CORE_RATIO)
        num_ring = num_particles - num_core

        core = self._create_sphere(num_core, self.core_radius)
        ring = self._create_ring(num_ring, self.ring_inner, self.ring_outer)
        return np.concatenate([core, ring], axis=0)

    def get_color(self):
        return (0.3, 0.6, 1.0)  # biru (fallback)

    def get_colors_array(self, num_particles):
        # Proporsi HARUS sama dengan get_positions(): inti dulu, lalu cincin
        num_core = int(num_particles * CORE_RATIO)
        num_ring = num_particles - num_core

        core_colors = np.tile(np.array([1.0, 0.85, 0.4]), (num_core, 1))  # kuning keemasan
        ring_colors = np.tile(np.array([0.3, 0.6, 1.0]), (num_ring, 1))   # biru
        return np.concatenate([core_colors, ring_colors], axis=0).astype(np.float32)

    def get_tilt(self):
        return 25.0

    def _create_sphere(self, count, radius):
        phi = np.random.uniform(0, 2 * np.pi, count)
        theta = np.arccos(np.random.uniform(-1, 1, count))
        x = radius * np.sin(theta) * np.cos(phi)
        y = radius * np.sin(theta) * np.sin(phi)
        z = radius * np.cos(theta)
        return np.stack([x, y, z], axis=-1).astype(np.float32)

    def _create_ring(self, count, inner_r, outer_r):
        angle = np.random.uniform(0, 2 * np.pi, count)
        radius = np.random.uniform(inner_r, outer_r, count)
        x = radius * np.cos(angle)
        z = radius * np.sin(angle)
        y = np.random.uniform(-0.05, 0.05, count)
        return np.stack([x, y, z], axis=-1).astype(np.float32)
