"""
effects/base_effect.py

Blueprint (Abstract Base Class) untuk semua visual effect.
Effect baru HARUS mewarisi class ini dan mengisi get_positions() & get_color().
main.py tidak perlu tahu detail tiap effect -- cukup memanggil method standar ini.
"""

from abc import ABC, abstractmethod


class BaseEffect(ABC):

    @abstractmethod
    def get_positions(self, num_particles):
        """WAJIB. Return NumPy float32 shape (num_particles, 3): posisi (x, y, z)."""

    @abstractmethod
    def get_color(self):
        """WAJIB. Return tuple (r, g, b), nilai 0.0-1.0 (satu warna rata)."""

    def get_colors_array(self, num_particles):
        """
        Opsional. Default None = pakai satu warna rata dari get_color().
        Effect yang butuh warna berbeda per partikel (Saturnus, Fireworks)
        menimpa ini dan return array float32 shape (num_particles, 3).
        """
        return None

    def get_tilt(self):
        """Opsional. Kemiringan tetap (derajat) di sumbu X."""
        return 0.0

    def get_motion_type(self):
        """
        Opsional. "full" = berputar 360 terus, "idle" = goyang halus,
        "none" = tidak ada rotasi tambahan.
        """
        return "full"

    def update(self, dt):
        """
        Opsional. Dipanggil tiap frame untuk effect dengan animasi internal
        (misal Fireworks). dt = detik sejak frame sebelumnya.
        """
        pass
