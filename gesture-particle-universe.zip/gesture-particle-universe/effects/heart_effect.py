"""
effects/heart_effect.py

Effect "Heart" -- partikel membentuk hati 3D dengan rumus parametrik klasik.
"""

import numpy as np
from effects.base_effect import BaseEffect


class HeartEffect(BaseEffect):
    def __init__(self, scale=0.85):
        self.scale = scale

    def get_positions(self, num_particles):
        t = np.random.uniform(-np.pi, np.pi, num_particles)  # posisi di sepanjang kurva
        p = np.random.uniform(-np.pi, np.pi, num_particles)  # untuk ketebalan sumbu Z

        x = 2.0 * (np.sin(t) ** 3)
        y = (
            2.0 * np.cos(t)
            - 0.7 * np.cos(2 * t)
            - 0.3 * np.cos(3 * t)
            - 0.1 * np.cos(4 * t)
        )
        z = np.sin(p) * 0.4

        return np.stack([x * self.scale, y * self.scale, z], axis=-1).astype(np.float32)

    def get_color(self):
        return (1.0, 0.1, 0.35)  # pink/merah muda

    def get_motion_type(self):
        return "idle"
