"""
Tes dasar yang TIDAK butuh webcam / GPU / MediaPipe.
Jalankan dari folder project:   python -m unittest discover tests -v
"""

import unittest
from types import SimpleNamespace

import numpy as np

from detectors.gesture_detector import recognize_gesture
from effects.firework_effect import FireworkEffect
from effects.galaxy_effect import GalaxyEffect
from effects.heart_effect import HeartEffect
from effects.lightning_effect import LightningEffect
from effects.nebula_effect import NebulaEffect
from effects.saturn_effect import SaturnEffect
from effects.text_effect import TextEffect

N = 500


def make_hand(fingers_up, thumb_up=False):
    """Landmark palsu (21 titik). fingers_up = [telunjuk, tengah, manis, kelingking]."""
    lm = [SimpleNamespace(x=0.5, y=0.7) for _ in range(21)]
    for tip, pip, mcp, up in zip([8, 12, 16, 20], [6, 10, 14, 18], [5, 9, 13, 17], fingers_up):
        lm[mcp].y = 0.6
        lm[pip].y = 0.5
        lm[tip].y = 0.3 if up else 0.65
    lm[4].y = 0.2 if thumb_up else 0.62
    return lm


class GestureTests(unittest.TestCase):
    def test_gestures(self):
        cases = {
            "FIST": make_hand([0, 0, 0, 0]),
            "THUMBS_UP": make_hand([0, 0, 0, 0], thumb_up=True),
            "OPEN_PALM": make_hand([1, 1, 1, 1]),
            "POINTING": make_hand([1, 0, 0, 0]),
            "PEACE": make_hand([1, 1, 0, 0]),
            "THREE": make_hand([1, 1, 1, 0]),
            "UNKNOWN": make_hand([0, 1, 0, 0]),
        }
        for expected, hand in cases.items():
            self.assertEqual(recognize_gesture(hand), expected)


class EffectTests(unittest.TestCase):
    EFFECTS = [NebulaEffect, SaturnEffect, TextEffect, HeartEffect,
               GalaxyEffect, FireworkEffect, LightningEffect]

    def test_positions_shape_and_dtype(self):
        for cls in self.EFFECTS:
            pos = cls().get_positions(N)
            self.assertEqual(pos.shape, (N, 3), cls.__name__)
            self.assertEqual(pos.dtype, np.float32, cls.__name__)
            self.assertTrue(np.isfinite(pos).all(), cls.__name__)

    def test_colors(self):
        for cls in self.EFFECTS:
            effect = cls()
            effect.get_positions(N)
            self.assertEqual(len(effect.get_color()), 3)
            colors = effect.get_colors_array(N)
            if colors is not None:
                self.assertEqual(colors.shape, (N, 3), cls.__name__)
                self.assertEqual(colors.dtype, np.float32, cls.__name__)

    def test_motion_type_valid(self):
        for cls in self.EFFECTS:
            self.assertIn(cls().get_motion_type(), ("full", "idle", "none"))

    def test_firework_update_runs(self):
        fw = FireworkEffect()
        fw.get_positions(N)
        for _ in range(300):  # ~5 detik pada 60 FPS, termasuk respawn
            fw.update(1 / 60)
        self.assertEqual(fw.positions.shape, (N, 3))
        self.assertTrue(np.isfinite(fw.positions).all())


if __name__ == "__main__":
    unittest.main()
