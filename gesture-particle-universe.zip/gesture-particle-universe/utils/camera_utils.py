"""
utils/camera_utils.py

Fungsi bantuan untuk mendeteksi webcam yang tersedia.
"""

import cv2


def list_available_cameras(max_check=5):
    """
    Mencoba membuka index kamera 0..max_check-1 dan mengembalikan
    daftar index yang berhasil dibuka, contoh: [0, 1].
    """
    available = []
    for index in range(max_check):
        cap = cv2.VideoCapture(index)
        if cap.isOpened():
            available.append(index)
        cap.release()  # wajib dilepas, supaya kamera tidak "terkunci"
    return available
