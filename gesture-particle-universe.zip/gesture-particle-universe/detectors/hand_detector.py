"""
detectors/hand_detector.py

Modul untuk mendeteksi tangan dan landmark-nya menggunakan MediaPipe Tasks API
(API resmi terbaru -- API lama 'mp.solutions' sudah dihapus oleh MediaPipe).
"""

import os

import cv2
import mediapipe as mp
from mediapipe.tasks.python import vision
from mediapipe.tasks.python.core.base_options import BaseOptions

from config.settings import MODEL_PATH

# Pasangan index landmark yang saling terhubung -- dipakai untuk menggambar
# "rangka tangan" (garis antar sendi). Data statis resmi dari MediaPipe.
HAND_CONNECTIONS = [
    (0, 1), (1, 2), (2, 3), (3, 4),          # ibu jari
    (0, 5), (5, 6), (6, 7), (7, 8),          # telunjuk
    (0, 9), (9, 10), (10, 11), (11, 12),     # jari tengah
    (0, 13), (13, 14), (14, 15), (15, 16),   # jari manis
    (0, 17), (17, 18), (18, 19), (19, 20),   # kelingking
    (5, 9), (9, 13), (13, 17),               # penghubung antar buku jari
]


class HandDetector:
    """
    Pembungkus MediaPipe Hand Landmarker (Tasks API).
    Menyembunyikan detail setup, dan menyediakan method sederhana
    find_hands() yang dipanggil dari main.py.
    """

    def __init__(self, max_hands=1, model_path=MODEL_PATH):
        if not os.path.exists(model_path):
            raise FileNotFoundError(
                f"File model tidak ditemukan: {model_path}\n"
                "Jalankan dulu:  python download_model.py"
            )

        base_options = BaseOptions(model_asset_path=model_path)
        options = vision.HandLandmarkerOptions(
            base_options=base_options,
            num_hands=max_hands,
            # VIDEO: cocok untuk frame webcam berurutan dengan timestamp manual
            running_mode=vision.RunningMode.VIDEO,
        )
        self.landmarker = vision.HandLandmarker.create_from_options(options)
        self.frame_timestamp_ms = 0

    def find_hands(self, frame, draw=True):
        """
        Mendeteksi tangan di satu frame webcam (format BGR).

        Return:
            frame: frame (mungkin sudah digambar landmark-nya)
            result: hasil deteksi MediaPipe (result.hand_landmarks)
        """
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)

        # VIDEO mode mewajibkan timestamp yang terus bertambah (ms)
        self.frame_timestamp_ms += 33  # asumsi ~30 FPS
        result = self.landmarker.detect_for_video(mp_image, self.frame_timestamp_ms)

        if result.hand_landmarks and draw:
            height, width, _ = frame.shape
            for hand_landmarks in result.hand_landmarks:
                self._draw_landmarks(frame, hand_landmarks, width, height)

        return frame, result

    def _draw_landmarks(self, frame, hand_landmarks, width, height):
        """Method privat: menggambar titik & garis landmark dengan OpenCV."""
        points = []
        for landmark in hand_landmarks:
            x_pixel = int(landmark.x * width)
            y_pixel = int(landmark.y * height)
            points.append((x_pixel, y_pixel))
            cv2.circle(frame, (x_pixel, y_pixel), 5, (0, 255, 0), -1)

        for start_idx, end_idx in HAND_CONNECTIONS:
            cv2.line(frame, points[start_idx], points[end_idx], (255, 255, 255), 2)
