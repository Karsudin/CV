"""
detectors/gesture_detector.py

Menentukan GESTURE (kepal, tangan terbuka, menunjuk, dst) berdasarkan posisi
landmark tangan dari MediaPipe.

- hand_detector.py    -> "di mana posisi tangan & jarinya?"  (deteksi)
- gesture_detector.py -> "gesture apa yang sedang dibentuk?" (interpretasi)

Catatan koordinat: Y makin kecil = makin ke ATAS di layar.
"""

# Index landmark 4 jari (selain ibu jari)
FINGER_TIPS = [8, 12, 16, 20]   # ujung: telunjuk, tengah, manis, kelingking
FINGER_PIPS = [6, 10, 14, 18]   # sendi tengah
FINGER_MCPS = [5, 9, 13, 17]    # pangkal jari (buku jari)

THUMB_TIP = 4

# Seberapa jauh (skala 0-1 dari tinggi frame) ujung ibu jari harus berada
# DI ATAS buku-buku jari agar dihitung "jempol ke atas". Naikkan kalau kepalan
# biasa sering salah terbaca THUMBS_UP, turunkan kalau jempol susah terdeteksi.
THUMB_UP_MARGIN = 0.05


def get_fingers_up(hand_landmarks):
    """
    Status 4 jari (bukan ibu jari): True = berdiri, False = terlipat.
    Urutan: [telunjuk, tengah, manis, kelingking]
    """
    return [
        hand_landmarks[tip].y < hand_landmarks[pip].y
        for tip, pip in zip(FINGER_TIPS, FINGER_PIPS)
    ]


def is_thumb_up(hand_landmarks):
    """
    True jika ujung ibu jari berada jelas di atas SEMUA buku jari lain
    (pose "jempol ke atas" dengan tangan tegak).
    """
    thumb_y = hand_landmarks[THUMB_TIP].y
    return all(
        thumb_y < hand_landmarks[mcp].y - THUMB_UP_MARGIN for mcp in FINGER_MCPS
    )


def recognize_gesture(hand_landmarks):
    """
    Return nama gesture: "FIST", "THUMBS_UP", "OPEN_PALM", "POINTING",
    "PEACE", "THREE", atau "UNKNOWN".
    """
    fingers_up = get_fingers_up(hand_landmarks)
    count = sum(fingers_up)

    if count == 0:
        # Semua 4 jari terlipat: bedakan kepalan biasa vs jempol ke atas.
        # (Pengecekan THUMBS_UP HARUS di sini, sebelum FIST dikembalikan.)
        return "THUMBS_UP" if is_thumb_up(hand_landmarks) else "FIST"
    if count == 4:
        return "OPEN_PALM"
    if count == 1 and fingers_up[0]:
        return "POINTING"
    if count == 2 and fingers_up[0] and fingers_up[1]:
        return "PEACE"
    if count == 3 and fingers_up[0] and fingers_up[1] and fingers_up[2]:
        return "THREE"

    return "UNKNOWN"
