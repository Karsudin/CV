"""
config/settings.py

Semua konstanta/pengaturan aplikasi dikumpulkan di satu tempat ini,
supaya mudah dicari dan diubah tanpa membongkar main.py.
"""

import os

# Folder utama project (satu level di atas folder 'config')
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# --- Window ---
WIDTH, HEIGHT = 1000, 700
WINDOW_TITLE = "Gesture Particle Universe"
TARGET_FPS = 60

# --- Partikel & animasi ---
NUM_PARTICLES = 500       # naikkan pelan-pelan sambil memantau FPS
LERP_SPEED = 0.08         # makin besar = morphing makin cepat
ROTATION_SPEED = 0.3      # derajat per frame untuk motion "full"
IDLE_AMPLITUDE = 6.0      # derajat goyangan untuk motion "idle"
IDLE_SPEED = 0.03         # kecepatan goyangan untuk motion "idle"
VIEW_DISTANCE = 10.0      # jarak "kamera virtual" ke partikel

# --- File & folder ---
MODEL_PATH = os.path.join(BASE_DIR, "assets", "hand_landmarker.task")
SCREENSHOT_DIR = os.path.join(BASE_DIR, "assets", "screenshots")
